/*
 * Copyright 2008 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package com.google.gwt.core.ext.typeinfo;

/**
 * Represents a wildcard type argument to a parameterized type.
 */
public interface JWildcardType extends JClassType {
  /**
   * Type of wildcard bound.
   */
  public enum BoundType {
    /**
     * Used when the declaration explicitly used ? extends Type.
     */
    EXTENDS,

    /**
     * Used when the declaration explicitly used ? super Type.
     */
    SUPER,

    /**
     * Used when the declaration did not specify a bound.
     */
    UNBOUND
  }

  JClassType getBaseType();

  BoundType getBoundType();

  JClassType getFirstBound();

  /**
   * Returns the lower bounds of this wildcard type. If no lower bounds were
   * declared, an empty array is returned.
   *
   * @return the lower bounds of this wildcard type
   */
  JClassType[] getLowerBounds();

  JClassType getUpperBound();

  /**
   * Returns the upper bounds of this wildcard type. If no upper bounds were
   * declared, an array containing {@link Object} is returned.
   *
   * @return the upper bounds of this wildcard type
   */

  JClassType[] getUpperBounds();
}
